# Section background images

Generated with the built-in image-generation tool, then converted to JPEG for the application. The images live in `public/images/` and are selected by the active section.

+## crops

Saved file: `public/images/crops.jpg`

Prompt: Wide photographic background for a farm management application: lush maize fields and cultivated farmland in southern Africa, morning light, natural realistic agricultural photography, no text or logos, landscape composition.

## livestock

Saved file: `public/images/livestock.jpg`

Prompt: Wide photographic background for a livestock management application: healthy cattle grazing in a green southern African pasture with farm fencing, warm daylight, realistic agricultural photography, no text or logos.

## operations

Saved file: `public/images/operations.jpg`

Prompt: Wide photographic background for farm operations software: a tractor beside an orderly farm shed with stacked harvest crates and irrigation equipment, southern African farmland, realistic photography, no text or logos.

## business

Saved file: `public/images/business.jpg`

Prompt: Wide photographic background for farm administration software: farm office desk with a closed ledger, calculator and basket of harvested maize, farmland visible through window, natural realistic photography, no readable text or logos.
