# Administration, accounts and password recovery

## Using the new screens

Sign in as an Owner or Administrator to open **Admin overview**. It lists every active and archived record in your business, register totals, staff accounts and recent activity. Search across record details, choose a register or status, then select **View all details**. The overview always covers all farms in your business; the top farm filter is disabled there.

Choose **Create staff account** to add a colleague to the same business. Set their role and temporary password. They must replace that password at first sign-in. **Team & access** also lets you change access or disable staff.

On the sign-in screen, **Create account** creates a separate farm workspace with its own Owner. It does not grant access to an existing business. Each business's administrators see only their own records and accounts.

Choose **Forgot password?** and enter the account email. When delivery is connected, the system submits a reset email to the delivery service. Open the link and enter your new password twice. Links expire after 30 minutes and work once. A successful reset invalidates other reset links and existing signed-in sessions. Disabled accounts cannot recover access this way.

## Connect Gmail

1. Enable Google 2-Step Verification and create an app password. See [Google instructions](https://support.google.com/accounts/answer/185833). Some managed accounts restrict app passwords.
2. Run `npm run configure-email` in the project folder. Enter your Gmail address, the app password (hidden), and the system URL.
3. Restart with `npm start`, then choose **Forgot password?** to request a link for a registered account.

The credential is saved in `storage/mail-config.json` with owner-only permissions, outside the public files and source archive. Never paste it into chat. The Node launcher sends through encrypted Gmail SMTP using a private authenticated bridge for PHP. This works with `npm start` and the Mac launcher. PHP-only Docker uses the webhook option below.

Alternatively set `GMAIL_ADDRESS`, `GMAIL_APP_PASSWORD` and `APP_URL` as server environment variables. Credentials are checked when a reset message is requested; configured status does not prove delivery.

## Alternative email webhook

Live email delivery requires your private Gmail settings or another configured service. The interface reports this explicitly. Existing administrator password resets and the owner recovery command remain available.

Configure these server environment variables:

- `APP_URL`: the trusted base URL where users open the system. Use HTTPS for a hosted system. Local testing supports `http://127.0.0.1:8080` or `http://localhost:8080`; these local links open only on the computer running the system.
- `PASSWORD_RESET_WEBHOOK_URL`: an HTTPS endpoint that accepts the JSON payload below and sends an email. This is a dedicated recovery integration, separate from farm alert notifications.
- `PASSWORD_RESET_WEBHOOK_TOKEN`: optional bearer credential expected by that endpoint.

The server sends a POST request with `event`, `to`, `subject`, `text`, `reset_url` and `expires_in_seconds` fields. The delivery endpoint must send `subject` and `text` to the `to` address and return a successful 2xx response only after accepting delivery. Ordinary provider APIs may need an adapter to accept this payload.

Local `npm start` reads process environment variables, not a `.env` file. Docker Compose passes these settings from its environment or `.env` file. Restart the server after configuration changes.

The public response is deliberately the same for an active account and an unknown address. Delivery failures are logged without exposing recipient details or reset tokens. The response does not prove an email was delivered.

## Files and stored data

- `src/password-reset.php`: configuration checks, recovery rate limits, email requests and token redemption.
- `public/api.php`: public registration/recovery actions and the protected administration summary.
- `public/app.js`: administration, account creation and recovery screens.
- `ffms_password_resets`: database table containing token digests, account references, password fingerprints and expiry times. Raw reset tokens are not stored in the database.
- `public/images/`: generated backgrounds for crops, livestock, operations and business sections.

The reset table is created automatically alongside the existing tables. Existing farm records and login credentials are retained.

## Checks

`tests/accounts.mjs` checks registration, admin permissions, business separation, archived details, missing email configuration, token expiry/reuse and session invalidation. Run it against a **fresh isolated** test server with matching `FFMS_STORAGE` and `TEST_URL`. The test-only token fixture refuses to run without a test storage path. Never point these tests at live data.

The Gmail files are `scripts/start.mjs` (launcher), `scripts/configure-email.mjs` (private setup) and `scripts/mail-bridge.mjs` (delivery). `tests/mail.mjs` tests a generated link through a fake mail sender, password reset and new-password sign-in without sending real email.
