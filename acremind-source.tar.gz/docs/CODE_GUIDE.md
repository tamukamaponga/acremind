# Understanding the farm management code

This guide explains where the code lives, how information moves through the system, and where to make common changes. The source files now have numbered sections and comments explaining the important decisions.

If you want to operate the application rather than edit its code, begin with [Using the system](USER_GUIDE.md).

## Read these files in this order

1. **`public/index.php`** — the small page that loads the application.
2. **`src/catalog.json`** — the list of registers and their form fields. Start with `farms` and `fields`.
3. **`public/app.js`** — the screens, buttons, forms and displayed calculations.
4. **`public/api.php`** — the requests the browser can send to the server.
5. **`src/app.php`** — permissions, database access and validation rules.
6. **`public/style.css`** — the colors, spacing, layout and phone/print styles.

You do not need to read every file before starting. Follow one action, such as saving a farm, from the form to the database.

## Folder map

```text
farm-management/
├── README.md                    Startup, configuration and release limits
├── docs/
│   ├── CODE_GUIDE.md             This guide for understanding the source
│   └── USER_GUIDE.md             Daily operations and writing useful notes
├── public/                      The only folder served to the browser
│   ├── index.php                HTML entry page
│   ├── app.js                   Screens and browser interactions
│   ├── style.css                Appearance and responsive layouts
│   ├── api.php                  Main JSON request endpoint
│   ├── services.php             Optional AI advice endpoint
│   ├── notifications.php        Optional alert delivery endpoint
│   └── favicon.svg              Small browser-tab icon
├── src/
│   ├── app.php                  Shared backend and business rules
│   └── catalog.json             Generated register/field definitions
├── scripts/
│   ├── build-catalog.cjs         Editable source of register definitions
│   ├── check.mjs                PHP and JavaScript syntax checks
│   ├── backup.php               Complete SQLite backup
│   ├── restore.php              Restore into an empty directory
│   ├── recover.php              Account recovery command
│   └── security-fixtures.php    Isolated test accounts only
├── tests/                       Synthetic-data verification scripts
├── storage/                     Private database, sessions and backups
├── legacy/                      Earlier prototype, not used by this release
├── deploy/                      Optional Apache configuration
├── package.json                 Dependencies and commands
└── Start Farm Management.command  Mac launcher
```

`node_modules/` contains downloaded tools and the PHP runtime. It is not where you edit the farm application's features. `storage/` contains live information and is not included in the source download.

## Example: what happens when you save a farm

```text
User fills in the farm form and presses Save record
    ↓
app.js: openEditor() collects the form values
    ↓
app.js: api() sends JSON to api.php?action=save
    ↓
api.php checks the session token and signed-in account
    ↓
app.php: saveRecord() checks permissions and field values
    ↓
app.php: validateWorkspace() checks linked records and farm rules
    ↓
Database update and audit entry are committed together
    ↓
app.js: refresh() loads the saved data and render() redraws the screen
```

If a validation check fails, the change is rolled back. The browser shows the error so the user can correct the form.

## Frontend sections in app.js

| Section                  | Purpose                                              | Useful functions                         |
| ------------------------ | ---------------------------------------------------- | ---------------------------------------- |
| Shared helpers and state | Track the current screen, session and loaded records | `$`, `$$`, `esc`, `rows`, `find`         |
| Server communication     | Send requests and display feedback                   | `api`, `refresh`, `toast`                |
| Display calculations     | Calculate visible stock and reminders                | `stock`, `alerts`                        |
| Shared layout            | Draw navigation, tables, cards and charts            | `shell`, `table`, `metrics`, `cashChart` |
| Main pages               | Build dashboard, registers and reports               | `dashboard`, `modulePage`, `reportPage`  |
| Navigation and events    | Choose a screen and attach button actions            | `render`, `bind`                         |
| Record forms             | Build fields and save edited records                 | `fieldHTML`, `openEditor`                |
| Exports and printing     | Produce CSV downloads and invoices                   | `exportCSV`, `printInvoice`              |
| External services        | Load forecasts and request optional AI advice        | `loadWeather`, `checkAI`, `generateAI`   |
| Accounts                 | Manage staff and sign-in screens                     | `loadTeam`, `teamEditor`, `renderAuth`   |

`state.records` holds the latest records loaded from the server. Changing this browser object alone does not save anything. A successful API request is what changes the database.

`esc()` makes stored text safe to display inside HTML. Use it when placing names or notes in HTML templates. Use `textContent` when an element only needs plain text.

The backend repeats important checks. Browser controls improve usability; they are not the authority for permissions or stock balances.

## Backend sections in app.php

| Section                        | Main responsibility                                                   |
| ------------------------------ | --------------------------------------------------------------------- |
| Storage and sessions           | Choose the data directory and configure the login session             |
| Database helpers               | Open SQLite/MySQL and run prepared statements                         |
| Authentication and permissions | Check account status, business ownership and role access              |
| Transactions                   | Keep a related set of changes together and prevent conflicting writes |
| Records and audit history      | Load saved records and record who changed them                        |
| Individual field validation    | Check required values, types, dates and options                       |
| Cross-record rules             | Check references, area, stock, payments and warehouse capacity        |
| Record lifecycle               | Create, edit, archive or restore with version checking                |
| Settings and alerts            | Read the business profile and prepare alert text                      |

### Important business rules

- Fields must fit inside their farm's total area.
- Plantings may reuse a field in different seasons, but overlapping allocations must fit.
- Linked records must belong to the same business and, where applicable, the same farm.
- Stock must not fall below zero.
- Received purchases add stock; confirmed sales remove it.
- Payments cannot exceed their linked invoice or purchase total.
- A stale record version is rejected so an old form cannot overwrite newer work.
- Archiving preserves history and reruns the same dependency and balance checks.

These rules belong in the backend even if the form also checks them.

## Main API actions

All actions below use `public/api.php?action=ACTION`.

| Action                | Method     | What it does                                                                     |
| --------------------- | ---------- | -------------------------------------------------------------------------------- |
| `session`             | GET        | Returns login state, a session token and whether initial setup is available      |
| `setup`               | POST       | Creates the first owner account only                                             |
| `login` / `logout`    | POST       | Starts or ends a login session                                                   |
| `password`            | POST       | Changes the signed-in account's password                                         |
| `state`               | GET        | Returns permitted modules, records and settings                                  |
| `save`                | POST       | Creates a record, or updates it when an ID/version is supplied                   |
| `archive` / `restore` | POST       | Changes whether a record is active                                               |
| `team`                | GET / POST | Lists or changes staff; owner/administrator access required                      |
| `audit`               | GET        | Lists recent activity; owner/administrator access required                       |
| `settings`            | POST       | Updates the business profile; owner/administrator access required                |
| `backup`              | GET        | Downloads records without account passwords; owner/administrator access required |

A record request contains the module name and its field values:

```json
{
  "module": "farms",
  "data": {
    "name": "Example Farm",
    "location": "Example location",
    "hectares": 20,
    "notes": "North access road becomes muddy after heavy rain."
  }
}
```

This is a request-body example, not a command to run. A real change also needs a valid login cookie and `X-CSRF-Token` header. An edit additionally supplies the record's `id` and latest `version`.

## How forms are defined

Edit **`scripts/build-catalog.cjs`**, then run **`npm run catalog`**. That command generates `src/catalog.json`.

| Helper | Meaning                                      | Example                                       |
| ------ | -------------------------------------------- | --------------------------------------------- |
| `f`    | General text or another specified field type | `f('name', 'Farm name')`                      |
| `n`    | Number with a minimum                        | `n('hectares', 'Area (ha)', true, 0.01)`      |
| `d`    | Date                                         | `d('date', 'Application date')`               |
| `sel`  | A list of allowed choices                    | `sel('status', 'Status', 'Active\|Inactive')` |
| `ref`  | A link to another register                   | `ref('farm', 'Farm', 'farms')`                |

The **key**, such as `hectares`, is used in saved data. The **label**, such as `Area (ha)`, is shown to the user. `required` controls whether the field must be completed. A reference stores another record's ID rather than copying its name.

For example, an optional field can be added to a register's field list:

```js
// Optional so existing records remain usable without a value.
f('access_note', 'Access instructions', 'textarea', false);
```

After editing the builder, regenerate the catalog and run the checks. Keep existing field keys stable. A new required field, changed unit or renamed key may also need a data migration and updated validation. Adding a whole module requires reviewing permissions, relationships and tests too.

Direct edits to `src/catalog.json` will be overwritten next time the builder runs.

## Where information is saved

| Table           | Contains                                                          |
| --------------- | ----------------------------------------------------------------- |
| `ffms_users`    | Accounts, password hashes, roles and session versions             |
| `ffms_records`  | Register name, business ID, field data, version and archive state |
| `ffms_audit`    | Who changed a record, when, and its before/after values           |
| `ffms_settings` | Business profile and currency                                     |
| `ffms_attempts` | Recent sign-in attempts used for throttling                       |

The `data` column in `ffms_records` is JSON. Different registers have different fields, defined by the catalog and checked in PHP. `tenant_id` identifies the business owning the record; it is not a farm ID.

The default SQLite file is `storage/ffms.sqlite`. Use the application's backup/restore tools rather than editing database files to change records.

## Common changes

| You want to change…                  | Start here                                                    |
| ------------------------------------ | ------------------------------------------------------------- |
| Colors, spacing or mobile layout     | The numbered sections in `public/style.css`                   |
| A field label or optional form field | `scripts/build-catalog.cjs`, then `npm run catalog`           |
| A dashboard card or report           | Page functions in `public/app.js`                             |
| Who can edit a module                | `allowed()` in `src/app.php`                                  |
| A rule spanning several records      | `validateWorkspace()` in `src/app.php`                        |
| A new API action                     | `public/api.php`, with permission checks and validation       |
| AI or delivery configuration         | `.env.example` and the optional-service sections in README.md |
| Daily operational notes              | The Notes field in the application's record form              |

## Keep the code readable

```sh
npm run format        # Apply consistent indentation and spacing
npm run format:check  # Check formatting without editing files
npm run check         # Check PHP and JavaScript syntax
```

Formatting skips live storage, downloaded dependencies and the old prototype. Use comments to explain _why_ a rule or unusual step exists. Avoid comments that simply repeat an obvious statement.

Before changing behavior, read the relevant tests and use a separate test database. The test setup and deployment limitations are documented in README.md and VERIFICATION.md.

## Short glossary

- **Frontend:** the code running in the browser.
- **Backend:** PHP running on the server.
- **API:** the agreed request/response interface between them.
- **JSON:** the text format used for records and API data.
- **PDO:** PHP's database interface.
- **Session:** the server's record of a signed-in browser.
- **CSRF token:** a value tying a change request to the current session.
- **Transaction:** changes committed together, or rolled back together if a check fails.
- **Version:** the record number used to detect stale edits.
- **Archive:** retain a record while excluding it from active views and calculations.
