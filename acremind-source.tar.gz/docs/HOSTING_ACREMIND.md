# Put AcreMind online

A downloadable ZIP is the application source, not a public website link. AcreMind needs PHP, a persistent database/storage directory, and HTTPS hosting. Once hosted, users open the host's HTTPS address on their phone or computer; your Mac can be off.

## Server requirements

- PHP 8.2 or newer, with PDO SQLite and cURL. Alternatively configure PDO MySQL with `DB_DSN`, `DB_USER`, and `DB_PASSWORD`.
- Serve only the `public/` directory as the website's document root. Keep `src/`, `scripts/`, and `storage/` outside the public web root.
- Give the PHP process read/write access to its private storage directory. Set `FFMS_STORAGE` to that persistent directory when using a container or custom layout.
- Enable HTTPS and keep storage across restarts and deployments. The included Dockerfile provides PHP and Apache; container hosts must mount persistent storage at `/var/www/html/storage` and route HTTPS traffic to port 80.

## Setup and account ownership

The source package deliberately excludes local accounts, farm records, sessions, and API keys. Before sharing the hosted address, open it yourself and create the first Owner account. Anyone using public Create account creates a separate farm business; create staff accounts from Admin overview when colleagues need access to your business.

To transfer existing records and accounts, take a complete database backup and restore it privately with `scripts/restore.php` into empty hosting storage. Do not upload the database into `public/`. Do not copy active sessions. Coordinate this before inviting other users so their new records are not overwritten.

## External services

Set `GEMINI_API_KEY` and optionally `GEMINI_MODEL` in the host's private environment settings. Set `APP_URL` to the real HTTPS address so password reset links point to the hosted system.

The local Gmail bridge runs with the Node launcher. PHP-only hosting and the included Docker image use the configured HTTPS password-reset webhook instead (`PASSWORD_RESET_WEBHOOK_URL` and optional `PASSWORD_RESET_WEBHOOK_TOKEN`). Arrange this delivery integration before promising email recovery to hosted users. See `docs/ACCOUNTS_AND_RECOVERY.md`.

## Confirm before sharing

Verify sign-in, adding/editing a test record, persistence after a restart, staff access restrictions, and phone layout. Verify actual email delivery and AI requests using the hosted private settings. Keep regular database backups. The current source package has not yet been deployed or verified on a hosting server.
