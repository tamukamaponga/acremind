# Using the farm management system

Use this guide for daily work and writing useful record notes. For the source code, see [Understanding the code](CODE_GUIDE.md).

## Open and sign in

1. Open **Start Farm Management.command**, or run `npm start` from the project folder.
2. Visit **http://127.0.0.1:8080** on this computer.
3. Sign in with your account email and current password. If given a temporary password, set your own when prompted.
4. Keep the local server running while using the application.

If the page does not open, check that the launcher window is still running. A local address opens this computer's server; it is not a public internet link.

## Register information in a useful order

| First add…                          | Then you can add…                           |
| ----------------------------------- | ------------------------------------------- |
| Farm                                | Fields, animals, resources and work records |
| Field and crop variety              | Plantings                                   |
| Planting                            | Applications, scouting and harvests         |
| Inventory item and supplier         | Purchase orders                             |
| Inventory item and customer         | Sales invoices                              |
| Confirmed sale or approved purchase | Linked payments                             |
| Employee                            | Assigned tasks and attendance               |
| Water source                        | Irrigation system and schedule              |
| Equipment                           | Maintenance and fuel records                |
| Warehouse and stock item            | Storage lots                                |

Use the sidebar to choose a register. Press **Add record**, complete the required fields, then press **Save record**. Use **View / edit** to review or correct an existing record.

The farm selector limits the view to one farm. Search narrows the current register. Export CSV downloads the records matching that register's farm/search filters.

## Write useful notes

Most record forms include an optional **Notes** box. Notes are saved with that specific record. They are operational information, separate from the explanatory comments in the source code.

A useful note answers: **What happened? What was done? What needs to happen next?** Add a date and responsible person when they help another worker follow up.

Example for a field:

```text
12 September — North gate becomes muddy after rain.
Use the eastern entrance for deliveries until the access road is repaired.
Next check: 15 September. Responsible: field manager.
```

Example for equipment:

```text
12 September — Pump vibration noticed during the morning run.
Stopped use and assigned a mechanic to inspect the mounting bolts.
Next action: record the inspection result before returning the pump to service.
```

Example for a purchase:

```text
Supplier confirmed delivery for Friday morning.
Check packaging and delivered quantity against the purchase order on arrival.
```

Use the dedicated fields for quantities, costs, dates and status. A number written only in Notes is not included in calculations, stock balances or alerts. For example, writing “received 50 kg” in Notes does not receive stock; set the purchase status and quantity correctly.

To update a note: open the record, edit Notes, and save. An update replaces the note text, so append new observations if you want earlier text to remain visible in the form. Record edits are also captured in the audit history.

## Follow a crop through a season

1. Register the farm and field area.
2. Add the crop variety and a planting record with dates, area and expected yield.
3. Update the growth stage and record applications, scouting and irrigation.
4. Record gross harvest and losses. Link a stock item measured in kg if the net harvest should enter inventory.
5. Review the production report to compare expected and actual yield.

Future plantings may reuse a field when their dates do not overlap. Overlapping allocations cannot exceed the field area.

## Understand stock and money

- Opening stock, stock movements, received purchases and linked net harvests affect available inventory.
- A **confirmed sale** reduces stock. Draft and cancelled sales do not.
- An invoice records a sale; a **payment** records cash received or spent. They are shown separately in reports.
- Enter payments once. Operational cost records and earned labour pay do not automatically create cash payments.
- Payments cannot exceed their linked order total.
- Storage lots track location, occupancy and quality; they do not duplicate stock receipts.

If saving is refused, read the message. It may mean there is insufficient stock, an invalid linked record, an area conflict or an overpayment. Correct the relevant fields rather than adding a note to work around the rule.

## Archive and restore

Archive a record when it should leave active views but remain in history. Open it, choose **Archive**, then confirm. Linked active records must be archived first.

Use **Archive** in the sidebar to restore a record. Restore parent records first, such as a farm before its fields. Restoring also checks capacity and balances.

## Reports and reminders

The dashboard summarizes saved records. Reports include production, cash flow, inventory value, budgets and operational totals. Each register has CSV export; sales records include printable invoices.

Alerts come from entered due dates, stock thresholds, expiry dates and recorded problems. They do not know about work that has not been entered.

Weather forecasts need coordinates and internet access. AI and email/SMS delivery need configured services. The application states when these are disconnected.

## Keep a backup

In **Settings**, an owner or administrator can download a records backup. For a complete backup including accounts and audit history, use `npm run backup`. The full restore and recovery procedures are in README.md.

Account credentials belong in the login and account settings, not operational Notes. Use **Forgot password?** on the sign-in screen when email delivery is configured, or ask an administrator to reset a forgotten staff password.

## Accounts and administration

Owners and administrators can open **Admin overview** to search all active and archived records, view complete details, and create staff accounts. **Create account** on the sign-in page creates a separate farm workspace. See [Accounts and recovery](ACCOUNTS_AND_RECOVERY.md) for Gmail setup and the full workflow.
