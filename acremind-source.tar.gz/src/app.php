<?php
/**
 * SHARED PHP BACKEND
 * Loads storage/session settings, opens the database and enforces farm rules.
 * Public endpoints include this file; it does not draw the browser screens.
 * "tenant_id" means the farm business that owns an account or record.
 */
declare(strict_types=1);
// 1. Storage and session setup
// Real data and session files live outside public/, so they cannot be downloaded as page assets.
const ROOT = __DIR__ . '/..';
$store = getenv('FFMS_STORAGE') ?: ROOT . '/storage';
if (!is_dir($store)) {
    mkdir($store, 0700, true);
}
if (!is_dir($store . '/sessions')) {
    mkdir($store . '/sessions', 0700, true);
}
ini_set('session.use_strict_mode', '1');
ini_set('session.save_path', $store . '/sessions');
ini_set('display_errors', '0');
ini_set('log_errors', '1');
date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'Africa/Lusaka');
session_name('ffms_session');
session_set_cookie_params([
    'httponly' => true,
    'secure' => getenv('FFMS_SECURE_COOKIES') === '1' || ($_SERVER['HTTPS'] ?? '') === 'on',
    'samesite' => 'Strict',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');
// 2. Database and response helpers
// Domain errors become a plain-language API message with an HTTP status code.
function fail(string $message, int $status = 422): never
{
    throw new DomainException($message, $status);
}
// Open one connection per request and create the current ffms_ tables if needed.
// SQLite is the local default; DB_DSN can select MySQL on a configured server.
function database(): PDO
{
    static $pdo;
    if ($pdo) {
        return $pdo;
    }
    global $store;
    $dsn = getenv('DB_DSN') ?: 'sqlite:' . $store . '/ffms.sqlite';
    $dbUser = getenv('DB_USER') ?: null;
    $dbPassword = getenv('DB_PASSWORD') ?: null;
    if (!getenv('DB_DSN') && getenv('DATABASE_URL')) {
        $url = parse_url(getenv('DATABASE_URL'));
        if (
            !$url ||
            !in_array($url['scheme'] ?? '', ['postgres', 'postgresql'], true) ||
            empty($url['host']) ||
            empty($url['path'])
        ) {
            throw new RuntimeException('Invalid database configuration.');
        }
        $dsn =
            'pgsql:host=' .
            $url['host'] .
            ';port=' .
            ($url['port'] ?? 5432) .
            ';dbname=' .
            rawurldecode(ltrim($url['path'], '/')) .
            ';sslmode=require';
        $dbUser = rawurldecode($url['user'] ?? '');
        $dbPassword = rawurldecode($url['pass'] ?? '');
    }
    $pdo = new PDO($dsn, $dbUser, $dbPassword, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    $sqlite = $driver === 'sqlite';
    if ($sqlite) {
        $pdo->exec('PRAGMA foreign_keys=ON');
        $pdo->exec('PRAGMA busy_timeout=5000');
    }
    $id = $sqlite
        ? 'INTEGER PRIMARY KEY AUTOINCREMENT'
        : ($driver === 'pgsql'
            ? 'BIGSERIAL PRIMARY KEY'
            : 'BIGINT PRIMARY KEY AUTO_INCREMENT');
    $engine = $driver === 'mysql' ? ' ENGINE=InnoDB' : '';
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ffms_users (id $id, tenant_id BIGINT NULL, name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, role VARCHAR(30) NOT NULL, active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 0, session_version INTEGER NOT NULL DEFAULT 1, created_at VARCHAR(30) NOT NULL)$engine",
    );
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ffms_records (id $id, tenant_id BIGINT NOT NULL, module VARCHAR(60) NOT NULL, data TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, archived_at VARCHAR(30) NULL, created_at VARCHAR(30) NOT NULL, updated_at VARCHAR(30) NOT NULL)$engine",
    );
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ffms_audit (id $id, tenant_id BIGINT NOT NULL, user_id BIGINT NOT NULL, actor VARCHAR(120) NOT NULL, action VARCHAR(60) NOT NULL, module VARCHAR(60) NOT NULL, record_id BIGINT NULL, before_data TEXT NULL, after_data TEXT NULL, created_at VARCHAR(30) NOT NULL)$engine",
    );
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ffms_settings (tenant_id BIGINT PRIMARY KEY, data TEXT NOT NULL)$engine",
    );
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ffms_attempts (id $id, identity VARCHAR(64) NOT NULL, attempted_at BIGINT NOT NULL)$engine",
    );
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ffms_password_resets (token_hash VARCHAR(64) PRIMARY KEY, user_id BIGINT NOT NULL, password_fingerprint VARCHAR(64) NOT NULL, expires_at BIGINT NOT NULL)$engine",
    );
    return $pdo;
}
// PostgreSQL uses sequences; LASTVAL is scoped to this connection.
function insertedId(): int
{
    return database()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'pgsql'
        ? (int) sql('SELECT LASTVAL()')->fetchColumn()
        : (int) database()->lastInsertId();
}
// Keep values in prepared-statement parameters instead of concatenating them into SQL.
function sql(string $s, array $args = []): PDOStatement
{
    $q = database()->prepare($s);
    $q->execute($args);
    return $q;
}
function now(): string
{
    return date('c');
}
function jsonValue(mixed $v): string
{
    return json_encode($v, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
// Load the form definitions generated by scripts/build-catalog.cjs.
function catalog(): array
{
    static $c;
    return $c ??= json_decode(
        file_get_contents(__DIR__ . '/catalog.json'),
        true,
        512,
        JSON_THROW_ON_ERROR,
    );
}
// 3. Authentication and permissions
// Recheck account status and session version on every request, including after staff changes.
function user(): ?array
{
    if (!isset($_SESSION['uid'])) {
        return null;
    }
    $u = sql(
        'SELECT id,tenant_id,name,email,role,active,must_change,session_version FROM ffms_users WHERE id=?',
        [$_SESSION['uid']],
    )->fetch();
    if (
        !$u ||
        !$u['active'] ||
        (int) $u['session_version'] !== ($_SESSION['sv'] ?? 0) ||
        time() - ($_SESSION['seen'] ?? 0) > 7200
    ) {
        $_SESSION = [];
        return null;
    }
    $_SESSION['seen'] = time();
    $u['tenant_id'] = (int) ($u['tenant_id'] ?: $u['id']);
    return $u;
}
function requireUser(): array
{
    $u = user();
    if (!$u) {
        fail('Please sign in.', 401);
    }
    return $u;
}
// Central role policy. Read access and write access are checked separately.
function allowed(array $u, string $module, bool $write = false): bool
{
    if (in_array($u['role'], ['Owner', 'Administrator', 'Manager'], true)) {
        return true;
    }
    $lists = [
        'Agronomist' => [
            'farms',
            'fields',
            'crops',
            'plantings',
            'applications',
            'scouting',
            'harvests',
            'water_sources',
            'irrigation_systems',
            'irrigation',
            'inventory',
            'tasks',
            'weather_logs',
            'market_prices',
        ],
        'Accountant' => [
            'farms',
            'fields',
            'crops',
            'plantings',
            'harvests',
            'inventory',
            'employees',
            'attendance',
            'suppliers',
            'purchases',
            'customers',
            'sales',
            'payments',
            'budgets',
            'loans',
            'market_prices',
        ],
        'Worker' => [
            'farms',
            'fields',
            'crops',
            'plantings',
            'animals',
            'animal_health',
            'feeding',
            'inventory',
            'stock_moves',
            'employees',
            'tasks',
            'attendance',
            'irrigation',
            'irrigation_systems',
            'water_sources',
            'weather_logs',
        ],
    ];
    if (!in_array($module, $lists[$u['role']] ?? [], true)) {
        return false;
    }
    if (!$write) {
        return true;
    }
    if ($u['role'] === 'Worker') {
        return in_array(
            $module,
            ['tasks', 'attendance', 'feeding', 'animal_health', 'irrigation', 'weather_logs'],
            true,
        );
    }
    if ($u['role'] === 'Accountant') {
        return in_array(
            $module,
            [
                'suppliers',
                'purchases',
                'customers',
                'sales',
                'payments',
                'budgets',
                'loans',
                'market_prices',
                'attendance',
            ],
            true,
        );
    }
    return !in_array($module, ['farms', 'inventory'], true);
}
function admin(array $u): void
{
    if (!in_array($u['role'], ['Owner', 'Administrator'], true)) {
        fail('Only an owner or administrator can do this.', 403);
    }
}
// 4. Transactions
// Lock writes before checking shared balances so simultaneous requests cannot overspend stock.
function beginWrite(int $tenant): void
{
    if (database()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
        database()->exec('BEGIN IMMEDIATE');
    } else {
        database()->beginTransaction();
        sql('SELECT id FROM ffms_users WHERE id=? FOR UPDATE', [$tenant]);
    }
    $GLOBALS['writing'] = true;
}
function commitWrite(): void
{
    database()->exec('COMMIT');
    $GLOBALS['writing'] = false;
}
function rollbackWrite(): void
{
    if ($GLOBALS['writing'] ?? false) {
        database()->exec('ROLLBACK');
        $GLOBALS['writing'] = false;
    }
}
// 5. Reading records and recording history
// Every query stays within one business. Archived records are excluded unless requested.
function records(int $tenant, bool $archived = false): array
{
    $rows = sql(
        'SELECT * FROM ffms_records WHERE tenant_id=?' .
            ($archived ? '' : ' AND archived_at IS NULL') .
            ' ORDER BY id DESC',
        [$tenant],
    )->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int) $r['id'];
        $r['version'] = (int) $r['version'];
        $r['data'] = json_decode($r['data'], true, 512, JSON_THROW_ON_ERROR);
    }
    return $rows;
}
// Record who changed what. Call within the same transaction as the record change.
function audit(
    array $u,
    string $action,
    string $module,
    ?int $id,
    mixed $before = null,
    mixed $after = null,
): void {
    sql(
        'INSERT INTO ffms_audit (tenant_id,user_id,actor,action,module,record_id,before_data,after_data,created_at) VALUES (?,?,?,?,?,?,?,?,?)',
        [
            $u['tenant_id'],
            $u['id'],
            $u['name'],
            $action,
            $module,
            $id,
            $before === null ? null : jsonValue($before),
            $after === null ? null : jsonValue($after),
            now(),
        ],
    );
}
// 6. Validate individual fields
// Only catalog fields are retained. Check required values, numbers, dates and allowed choices.
function validateData(string $module, array $input): array
{
    $result = [];
    foreach (catalog()[$module]['fields'] as $f) {
        $v = $input[$f['key']] ?? null;
        if ($v === null || $v === '') {
            if ($f['required']) {
                fail($f['label'] . ' is required.');
            }
            $result[$f['key']] = null;
            continue;
        }
        if (!is_scalar($v)) {
            fail('Invalid ' . $f['label'] . '.');
        }
        if ($f['type'] === 'number') {
            if (
                !is_numeric($v) ||
                !is_finite((float) $v) ||
                (float) $v < ($f['min'] ?? 0) ||
                (float) $v > 1000000000
            ) {
                fail('Enter a valid ' . $f['label'] . '.');
            }
            $v = round((float) $v, 4);
        } elseif ($f['type'] === 'reference') {
            if (!ctype_digit((string) $v) || (int) $v < 1) {
                fail('Choose a valid ' . $f['label'] . '.');
            }
            $v = (int) $v;
        } else {
            $v = trim((string) $v);
            if ($f['required'] && $v === '') {
                fail($f['label'] . ' is required.');
            }
            if (strlen($v) > ($f['type'] === 'textarea' ? 6000 : 255)) {
                fail($f['label'] . ' is too long.');
            }
            if ($f['type'] === 'date') {
                $date = DateTimeImmutable::createFromFormat('!Y-m-d', $v);
                if (!$date || $date->format('Y-m-d') !== $v) {
                    fail('Enter a valid ' . $f['label'] . '.');
                }
            }
            if ($f['type'] === 'select' && !in_array($v, $f['options'], true)) {
                fail('Choose a valid ' . $f['label'] . '.');
            }
            if ($f['type'] === 'email' && $v !== '' && !filter_var($v, FILTER_VALIDATE_EMAIL)) {
                fail('Enter a valid email.');
            }
        }
        $result[$f['key']] = $v;
    }
    return $result;
}
// 7. Cross-record business rules
// Received purchases and confirmed sales count; quotations, drafts and cancellations do not.
function stockBalances(array $rows): array
{
    $balances = [];
    foreach ($rows as $r) {
        if ($r['module'] === 'inventory') {
            $balances[$r['id']] = $r['data']['opening'];
        }
    }
    foreach ($rows as $r) {
        $d = $r['data'];
        $item = $d['item'] ?? null;
        if (!$item || !array_key_exists($item, $balances)) {
            continue;
        }
        $delta = match ($r['module']) {
            'stock_moves' => $d['quantity'] * ($d['direction'] === 'In' ? 1 : -1),
            'purchases' => $d['status'] === 'Received' ? $d['quantity'] : 0,
            'sales' => $d['status'] === 'Confirmed' ? -$d['quantity'] : 0,
            'harvests' => $d['quantity'] - $d['loss'],
            default => 0,
        };
        $balances[$item] += $delta;
    }
    return $balances;
}
// Check the entire active business after a proposed change.
// If any link, area, stock or payment rule fails, the endpoint rolls back the transaction.
function validateWorkspace(array $rows): void
{
    $byId = [];
    $fieldAreas = [];
    $plantedAreas = [];
    $names = [];
    foreach ($rows as $r) {
        $byId[$r['id']] = $r;
    }
    foreach ($rows as $r) {
        $d = $r['data'];
        $m = $r['module'];
        foreach (catalog()[$m]['fields'] as $f) {
            if ($f['type'] === 'reference' && !empty($d[$f['key']])) {
                $target = $byId[$d[$f['key']]] ?? null;
                if (!$target || $target['module'] !== $f['ref']) {
                    fail('Restore or select an active ' . $f['label'] . ' for ' . $d['name'] . '.');
                }
                if (
                    isset($d['farm'], $target['data']['farm']) &&
                    $d['farm'] !== $target['data']['farm']
                ) {
                    fail('Linked records must belong to the same farm.');
                }
            }
        }
        $unique = $m . '|' . ($d['farm'] ?? '') . '|' . strtolower($d['name']);
        if (isset($names[$unique])) {
            fail('An active ' . $m . ' record with that name already exists.');
        }
        $names[$unique] = true;
        if ($m === 'farms') {
            if (
                ($d['latitude'] !== null && abs($d['latitude']) > 90) ||
                ($d['longitude'] !== null && abs($d['longitude']) > 180)
            ) {
                fail('Coordinates are outside the valid range.');
            }
            if (($d['latitude'] === null) !== ($d['longitude'] === null)) {
                fail('Provide both latitude and longitude.');
            }
            if (!empty($d['boundary'])) {
                $geo = json_decode($d['boundary'], true);
                if (
                    !is_array($geo) ||
                    !in_array($geo['type'] ?? '', ['Polygon', 'MultiPolygon'], true) ||
                    empty($geo['coordinates'])
                ) {
                    fail('Boundary must be a GeoJSON Polygon or MultiPolygon.');
                }
            }
        }
        if ($m === 'fields') {
            $fieldAreas[$d['farm']] = ($fieldAreas[$d['farm']] ?? 0) + $d['hectares'];
            if ($d['ph'] !== null && $d['ph'] > 14) {
                fail('Soil pH must be between 0 and 14.');
            }
        }
        if ($m === 'plantings') {
            if ($d['harvest_on'] < $d['planted_on']) {
                fail('Harvest cannot precede planting.');
            }
            if ($d['hectares'] > $byId[$d['field']]['data']['hectares']) {
                fail('Planted area exceeds the field area.');
            }
            if (!in_array($d['stage'], ['Harvested', 'Failed'], true)) {
                $plantedAreas[$d['field']][] = [
                    'date' => $d['planted_on'],
                    'delta' => $d['hectares'],
                ];
                $plantedAreas[$d['field']][] = [
                    'date' => date('Y-m-d', strtotime($d['harvest_on'] . ' +1 day')),
                    'delta' => -$d['hectares'],
                ];
            }
        }
        if ($m === 'harvests') {
            if ($d['loss'] > $d['quantity']) {
                fail('Harvest loss cannot exceed the harvest quantity.');
            }
            if ($d['date'] < $byId[$d['planting']]['data']['planted_on']) {
                fail('Harvest cannot precede planting.');
            }
            if ($d['item'] && strtolower($byId[$d['item']]['data']['unit']) !== 'kg') {
                fail('Harvest stock items must use kg.');
            }
        }
        if ($m === 'animals' && $d['status'] === 'Dead' && !$d['death_date']) {
            fail('Record the death date.');
        }
        if (
            $m === 'animals' &&
            $d['death_date'] &&
            $d['birth_date'] &&
            $d['death_date'] < $d['birth_date']
        ) {
            fail('Death cannot precede birth.');
        }
        if ($m === 'budgets' && $d['end_date'] < $d['date']) {
            fail('Budget end date cannot precede its start.');
        }
        if ($m === 'loans' && $d['repaid'] > $d['principal']) {
            fail('Principal repaid cannot exceed the loan principal.');
        }
        if ($m === 'equipment' && $d['salvage'] > $d['cost']) {
            fail('Residual value cannot exceed purchase value.');
        }
        if ($m === 'storage_lots' && $d['spoilage'] > $d['quantity']) {
            fail('Spoilage cannot exceed stored quantity.');
        }
        if ($m === 'storage_lots' && $d['dispatch_on'] && $d['dispatch_on'] < $d['date']) {
            fail('Dispatch cannot precede storage.');
        }
        if ($m === 'weather_logs' && $d['humidity'] > 100) {
            fail('Humidity cannot exceed 100%.');
        }
        if ($m === 'suppliers' && $d['rating'] !== null && $d['rating'] > 5) {
            fail('Rating cannot exceed 5.');
        }
        if ($m === 'payments') {
            if ($d['sale'] && ($d['direction'] !== 'Income' || $d['purchase'])) {
                fail('Sales payments must be income and cannot link a purchase.');
            }
            if ($d['purchase'] && $d['direction'] !== 'Expense') {
                fail('Purchase payments must be expenses.');
            }
            if ($d['sale'] && $byId[$d['sale']]['data']['status'] !== 'Confirmed') {
                fail('Confirm the invoice before recording payment.');
            }
            if (
                $d['purchase'] &&
                !in_array($byId[$d['purchase']]['data']['status'], ['Approved', 'Received'], true)
            ) {
                fail('Approve the purchase before recording payment.');
            }
        }
    }
    // Total fields must fit their farm; planting dates determine whether allocations overlap.
    foreach ($fieldAreas as $farm => $size) {
        if ($size > $byId[$farm]['data']['hectares'] + 0.00001) {
            fail('Active field areas exceed the total farm area.');
        }
    }
    foreach ($plantedAreas as $field => $events) {
        usort($events, fn($a, $b) => strcmp($a['date'], $b['date']) ?: $a['delta'] <=> $b['delta']);
        $size = 0;
        foreach ($events as $event) {
            $size += $event['delta'];
            if ($size > $byId[$field]['data']['hectares'] + 0.00001) {
                fail(
                    'Overlapping plantings exceed the field area. Check planting and harvest dates.',
                );
            }
        }
    }
    foreach (stockBalances($rows) as $id => $balance) {
        if ($balance < -0.00001) {
            fail(
                'Insufficient stock for ' .
                    $byId[$id]['data']['name'] .
                    '. Available stock cannot become negative.',
            );
        }
    }
    $paid = [];
    $stored = [];
    foreach ($rows as $r) {
        $d = $r['data'];
        if ($r['module'] === 'payments') {
            foreach (['sale', 'purchase'] as $key) {
                if ($d[$key]) {
                    $paid[$d[$key]] = ($paid[$d[$key]] ?? 0) + $d['amount'];
                }
            }
        }
        if ($r['module'] === 'storage_lots' && !$d['dispatch_on']) {
            $stored[$d['warehouse']] =
                ($stored[$d['warehouse']] ?? 0) + $d['quantity'] - $d['spoilage'];
        }
    }
    // Enforce invoice/order payment limits and warehouse occupancy after adding the totals.
    foreach ($paid as $id => $amount) {
        if (
            $amount >
            round($byId[$id]['data']['quantity'] * $byId[$id]['data']['unit_price'], 2) + 0.005
        ) {
            fail('Payments exceed the order total.');
        }
    }
    foreach ($stored as $id => $qty) {
        if ($qty > $byId[$id]['data']['capacity'] + 0.00001) {
            fail('Stored lots exceed warehouse capacity.');
        }
    }
}
// 8. Shared create / edit / archive / restore workflow
// The caller must begin a transaction and commit only after this function succeeds.
// A version number rejects edits made from an outdated screen.
function saveRecord(array $u, string $module, array $payload, string $operation = 'save'): int
{
    if (!isset(catalog()[$module])) {
        fail('Unknown module.', 404);
    }
    if (!allowed($u, $module, true)) {
        fail('Your role cannot change these records.', 403);
    }
    $id = (int) ($payload['id'] ?? 0);
    $before = null;
    if ($id) {
        $before = sql('SELECT * FROM ffms_records WHERE id=? AND tenant_id=? AND module=?', [
            $id,
            $u['tenant_id'],
            $module,
        ])->fetch();
        if (!$before) {
            fail('Record not found.', 404);
        }
        if ((int) ($payload['version'] ?? 0) !== (int) $before['version']) {
            fail('This record changed. Refresh and try again.', 409);
        }
        if ($operation !== 'restore' && $before['archived_at']) {
            fail('Restore this record before editing it.');
        }
        if ($operation === 'restore' && !$before['archived_at']) {
            fail('This record is already active.');
        }
    } elseif ($operation !== 'save') {
        fail('Choose a record.');
    }
    $data =
        $operation === 'save'
            ? validateData($module, $payload['data'] ?? [])
            : json_decode($before['data'], true);
    if ($module === 'inventory' && $before && $operation === 'save') {
        $old = json_decode($before['data'], true);
        if ($data['unit'] !== $old['unit']) {
            foreach (records($u['tenant_id'], true) as $linked) {
                if (($linked['data']['item'] ?? null) === $id) {
                    fail(
                        'Stock units cannot change after transactions exist. Create a new item for a different unit.',
                    );
                }
            }
        }
    }
    if (
        $module === 'purchases' &&
        in_array($data['status'], ['Approved', 'Received'], true) &&
        !in_array($u['role'], ['Owner', 'Administrator', 'Manager'], true)
    ) {
        fail('A manager must approve and receive purchases.', 403);
    }
    if ($id) {
        sql(
            'UPDATE ffms_records SET data=?,archived_at=?,version=version+1,updated_at=? WHERE id=? AND tenant_id=?',
            [
                jsonValue($data),
                $operation === 'archive' ? now() : null,
                now(),
                $id,
                $u['tenant_id'],
            ],
        );
    } else {
        sql(
            'INSERT INTO ffms_records (tenant_id,module,data,created_at,updated_at) VALUES (?,?,?,?,?)',
            [$u['tenant_id'], $module, jsonValue($data), now(), now()],
        );
        $id = insertedId();
    }
    validateWorkspace(records($u['tenant_id']));
    audit(
        $u,
        $operation === 'save' ? ($before ? 'update' : 'create') : $operation,
        $module,
        $id,
        $before ? json_decode($before['data'], true) : null,
        $data,
    );
    return $id;
}
// 9. Business settings and alert summaries
function settings(int $tenant): array
{
    $value = sql('SELECT data FROM ffms_settings WHERE tenant_id=?', [$tenant])->fetchColumn();
    return ($value ? json_decode($value, true) : []) + [
        'name' => 'My farm business',
        'currency' => 'ZMW',
        'address' => '',
        'phone' => '',
    ];
}
// Build text for a configured delivery service. This helper itself does not send anything.
function notificationSummary(int $tenant): array
{
    $rows = records($tenant);
    $balances = stockBalances($rows);
    $soon = date('Y-m-d', time() + 7 * 86400);
    $messages = [];
    foreach ($rows as $r) {
        $d = $r['data'];
        $m = $r['module'];
        if ($m === 'inventory') {
            if (($balances[$r['id']] ?? 0) <= $d['minimum']) {
                $messages[] =
                    $d['name'] .
                    ': low stock (' .
                    ($balances[$r['id']] ?? 0) .
                    ' ' .
                    $d['unit'] .
                    ').';
            }
            if ($d['expiry'] && $d['expiry'] <= $soon) {
                $messages[] = $d['name'] . ': expiry ' . $d['expiry'] . '.';
            }
        }
        if (
            $m === 'scouting' &&
            $d['status'] !== 'Resolved' &&
            in_array($d['severity'], ['High', 'Critical'], true)
        ) {
            $messages[] = $d['name'] . ': ' . $d['severity'] . ' pest/disease observation.';
        }
        if (
            in_array($m, ['water_sources', 'irrigation_systems'], true) &&
            in_array($d['status'], ['Low', 'Unavailable', 'Fault'], true)
        ) {
            $messages[] = $d['name'] . ': ' . $d['status'] . '.';
        }
        $due = $d['next_due'] ?? null;
        if (
            in_array($m, ['tasks', 'irrigation'], true) &&
            !in_array($d['status'], ['Done', 'Completed', 'Cancelled'], true)
        ) {
            $due = $d['date'];
        }
        if ($m === 'plantings' && !in_array($d['stage'], ['Harvested', 'Failed'], true)) {
            $due = $d['harvest_on'];
        }
        if (
            $due &&
            $due <= $soon &&
            !in_array($d['status'] ?? '', ['Cancelled', 'Settled'], true)
        ) {
            $messages[] = $d['name'] . ': due ' . $due . '.';
        }
    }
    return $messages;
}
